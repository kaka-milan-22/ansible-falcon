#!/bin/bash 
# ***********************************************
# 
#       Filename: entrypoint.sh
# 
#         Author: xwisen 1031649164@qq.com
#    Description: ---
#         Create: 2017-05-02 17:43:08
#  Last Modified: 2017-05-02 17:43:08
# ***********************************************

./env/bin/python wsgi.py

